//Valid-Parentheses
class Solution {
public:
    bool isValid(string s) {
        stack<int> val;
    
        for (int i = 0; i < s.length(); i++) {
            
            if (s[i] == '(') {
                val.push(0);
            } else if (s[i] == ')') {
                if (val.empty() || val.top() != 0) {
                    return false;
                } else {
                    val.pop();
                }
            }
            
            if (s[i] == '[') {
                val.push(1);
            } else if (s[i] == ']') {
                if (val.empty() || val.top() != 1) {
                    return false;
                } else {
                    val.pop();
                }
            }
            
            if (s[i] == '{') {
                val.push(2);
            } else if (s[i] == '}') {
                if (val.empty() || val.top() != 2) {
                    return false;
                } else {
                    val.pop();
                }
            }
        };
        
        if (val.empty()) {
            return true;
        } else {
            return false;
        }
    };
};

// Backspace String Compare
class Solution {
public:
    bool backspaceCompare(string S, string T) {
        
        stack<char> x;
        stack<char> y;

        
        for (int i = 0; i < S.size(); i++) {
            if (S[i] != '#') {
                x.push(S[i]);
            } else if (x.size() != 0 && S[i] == '#') {
                x.pop();
            } 
        }
        
        for (int i = 0; i < T.size(); i++) {
            if (T[i] != '#') {
                y.push(T[i]);
            } else if (y.size() != 0 && T[i] == '#') {
                y.pop();
            }
        }
        
        if (x.size() == y.size()) {
            for (int i = 0; i < x.size(); i++) {
                if (x.top() != y.top()) {
                    return false;
                }
                x.pop();
                y.pop();
            }
            
            return true;
        } else {
            return false;
        } 
        
    }
};

//Implement Queue using Stacks
class MyQueue {
public:
    /** Initialize your data structure here. */
    stack<int> val, temp;

    MyQueue() {
    }
    
    /** Push element x to the back of queue. */
    void push(int x) {
        val.push(x);
    }
    
    /** Removes the element from in front of queue and returns that element. */
    int pop() {
        while(val.size() != 1) {
            temp.push(val.top());
            val.pop();
        }
        
        int x = val.top();
        val.pop();
        
        for (int i = 0; i < temp.size(); i++) {
            val.push(temp.top());
            temp.pop();
        }
        
        return x;
    }
    
    /** Get the front element. */
    int peek() {
        
        while(val.size() != 1) {
            temp.push(val.top());
            val.pop();
        }
        
        int x = val.top();
        
        for (int i = 0; i < temp.size(); i++) {
            val.push(temp.top());
            temp.pop();
        }
        
        return x;
    }
    
    /** Returns whether the queue is empty. */
    bool empty() {
        if (val.size() == 0) {
            return true;
        }
        
        return false;
    }
};

//Implement Stacks using Queue
class MyStack {
public:
    /** Initialize your data structure here. */
    queue<int> que;

    MyStack() {
    }
    
    /** Push element x onto stack. */
    void push(int x) {
        que.push(x);
        
		for(int i = 1; i < que.size(); ++i) {
            
			que.push(que.front());
			que.pop();
		}
        
    }
    
    /** Removes the element on top of the stack and returns that element. */
    int pop() {
        int x = que.front();
		que.pop();
        
        return x;
    };
    
    /** Get the top element. */
    int top() {
        return que.front();
    }
    
    /** Returns whether the stack is empty. */
    bool empty() {
        return que.empty();
    }
};


