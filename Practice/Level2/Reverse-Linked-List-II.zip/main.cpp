#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
public:
    ListNode* reverseBetween(ListNode* head, int m, int n) {
        if(head == NULL || head -> next == NULL) {
         return head;   
        }
        
        m--; n--;
        
        ListNode* first = head;
        ListNode* last = head;
        ListNode *pre,*mover,*current;
        int counter = 0;
        
        for (counter; counter < m-1; counter++) {
            first = first -> next;
            last = last -> next;
        }
        
        for (counter; counter <= n; counter++) {
            last = last -> next;
        }

        if (m == 0) {
            pre = last;
            current = head;
            mover = head -> next;
        } else {
            pre = last;
            current = first -> next;
            mover = current -> next;
        }
        
        while (current != NULL && current != last) {
            current -> next = pre;
            pre = current;
            current = mover;
            if (mover !=NULL && mover != last)
            {
                mover = mover -> next;
            }
        }
        
        if (m > 0) {
            first -> next = pre;
            return head;
        }
        
        return pre;
    }
};



int main() {
  std::cout << "Hello World!\n";
}