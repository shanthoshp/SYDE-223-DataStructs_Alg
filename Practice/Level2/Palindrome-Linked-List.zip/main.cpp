#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
public:
    bool isPalindrome(ListNode* head) {
        vector<int> checkSame;
        while (head != NULL) {
            checkSame.push_back(head -> val);
            head = head -> next; 
        }
        
        int i = 0;
        int j = checkSame.size() - 1;
        
        
        while (i < j) {
            if (checkSame[i] != checkSame[j]) {
                return false;
            }
            ++i;
            --j;
        }
        
        return true;
    }
};

int main() {
}