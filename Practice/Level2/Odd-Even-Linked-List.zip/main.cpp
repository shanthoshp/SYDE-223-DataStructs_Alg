#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
public:
    ListNode* oddEvenList(ListNode* head) {
        
        if(head == NULL || head -> next == NULL) {
            return head;
        }
        ListNode* odd = head;
        ListNode* even = head->next;
        ListNode* split = even;
        
        while(odd != NULL && even != NULL && even -> next != NULL && odd -> next != NULL) {
            odd -> next = odd->next->next;
            even -> next = even->next->next;
            odd = odd -> next;
            even = even -> next;
        }
        
        odd -> next = split;
        return head;
    }
};

int main() {
  std::cout << "Hello World!\n";
}