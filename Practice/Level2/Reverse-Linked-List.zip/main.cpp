#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
  public:
  ListNode* reverseList(ListNode* head) {
  
  ListNode *previous;
  ListNode *current;
  ListNode *mover;
  current = head;
  mover = head;
  previous = NULL;

  if (head == NULL || head -> next == NULL) {
    return head;
  }

  while (current != NULL) {
    mover = current -> next;
    current -> next = previous;
    previous = current;
    current = mover;
  }
  head = previous;

  return head;
  }
};

int main() {
}