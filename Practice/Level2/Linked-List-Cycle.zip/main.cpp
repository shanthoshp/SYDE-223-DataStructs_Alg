#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
public:
    bool hasCycle(ListNode *head) {
        ListNode *mover = head;
        ListNode *current = head;
        ListNode *checker = head;
        
        
        if (head == NULL || head -> next == NULL || head -> next -> next == NULL) {
            return false;
        }
        
        while (current != NULL) {
            
            if (checker -> next == NULL || mover -> next == NULL) {
                return false;
            } else {
                checker = checker -> next -> next -> next;
                mover = mover -> next -> next;
                current = current -> next;
            }
            
            if (current == mover) {
                return true;
            }
        }
        
        return false;
        
    }
};
int main() {
}