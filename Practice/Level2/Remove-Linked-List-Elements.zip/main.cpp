#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
public:
    ListNode* removeElements(ListNode* head, int val) {
        
        while (head && head -> val == val) {
            head = head -> next;
        }
        
        if (head == NULL) {
            return NULL;
        }

        ListNode *prev = head;
        ListNode *mover = head -> next;
        
        while (mover != NULL) {
            
            if (mover -> val == val) {
             prev -> next = mover -> next;
             mover = mover -> next;
            } else {
              prev = mover;
              mover = mover -> next;
            }
        }
        
        return head;
    }
};