#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
public:
    vector<ListNode*> splitListToParts(ListNode* root, int k) {
        vector<ListNode*> ans;
        int size = 0;
        ListNode* mover = root;
        
        while (root != NULL) {
            ++size;
            root = root ->next;
        }
        
        int full = size/k;
        int extra = size%k;
        
        for (int i = 0; i < k; ++i) {
            ListNode* vec = mover;
            ListNode* copy = NULL;
            int len = (i < extra) ? (full + 1): full;
            for (int j = 0; j < len; ++j) {
                copy = mover;
                mover = mover -> next;
            }
            
            if (copy != NULL){
                copy -> next = NULL;
            } 
            
            ans.push_back(vec);
        }
        
        return ans;
    }
};

int main() {
  std::cout << "Hello World!\n";
}