#include <iostream>
#include <stdlib.h>
#include <string>
#include <cassert>
#include <random>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;

//Definition for single linked list

struct ListNode {
  int val;
  ListNode *next;

  ListNode(int x) {
    val = x;
    next = NULL;
  }
};

class Solution {
  public:
  ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
    int sizeA = 0;
    int sizeB = 0;
    ListNode *a = headA;
    ListNode *b = headB;

    while (headA != NULL) {
      headA = headA -> next;
      sizeA++;
    }

     while (headB != NULL) {
      headB = headB -> next;
      sizeB++;
    }

    if (sizeA > sizeB) {
        for (int i = 0; i < sizeA - sizeB; i++) {
            a = a -> next;
        }
    }
      
    if (sizeA < sizeB) {
        for (int i = 0; i < sizeB - sizeA; i++) {
            b = b -> next;
        }
    }
      
    while(a != NULL) {
        if (a == b) {
            return a;
        }
        
        a = a -> next;
        b = b -> next;
    }
      return NULL;
    };
};


int main() {
  std::cout << "Hello World!\n";
}